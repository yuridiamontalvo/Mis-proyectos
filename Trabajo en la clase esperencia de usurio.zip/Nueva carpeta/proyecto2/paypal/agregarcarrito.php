<?php
include('./conexio.php');
$id = $_GET['id'];
$sql = "INSERT INTO carrito(idproducto) VALUE ($id)";
$resultado = mysqli_query($conn, $sql);


if($resultado){
    header("Location: ../product-list.php");

}else{
    echo "<script>
    alert('error')
    window.location= '../product-list.php'
    </script>";
}
?>