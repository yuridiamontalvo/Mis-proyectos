<?php
$serverName = "127.0.0.1\\COMPAC";  // IP y nombre de la instancia del servidor SQL (asegúrate de que sea correcto)
$connectionOptions = array(
    "Database" => "adPRUEBAS_LLAMADAS",  // Nombre de tu base de datos
    "Uid" => "sa",                      // Usuario de SQL Server
    "PWD" => "Compac$2019",              // Contraseña del usuario `sa`
    "Encrypt" => "optional"             // Configura la encriptación como opcional
);

try {
    // Crear la conexión PDO
    $conn = new PDO("sqlsrv:Server=$serverName;Database=" . $connectionOptions['Database'], 
                    $connectionOptions['Uid'], 
                    $connectionOptions['PWD']);
    
    // Establecer el modo de error para que PDO arroje excepciones
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    //echo "Conexión exitosa!";
} catch (PDOException $e) {
    // Si hay un error, lo mostramos
    echo "Error de conexión: " . $e->getMessage();
}

?>

