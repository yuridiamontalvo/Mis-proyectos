<?php
include("./conexio.php");

$user = $_POST['usuario'];
$pass = $_POST['password'];

$sql = "SELECT * FROM clientes WHERE nombre = '$user' AND contraseña = '$pass'";
$resultado = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($resultado);


if($row['nombre'] == $user && $row['contraseña'] == $pass){
    header("Location: ../inicio.html");

}else{
    echo "<script>
    alert('Usuario o contraseña incorrectos')
    window.location= '../pagina2.html'
    </script>";
}
?>