<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://www.paypal.com/sdk/js?client-id=AZfOlrndy86TfAfbexznnP_oYcKEVkonqInFZVGpgdaxmH8lZ6XzJoBJLs1j7FeFHJCUKy8ccwrhv-af"></script>


</head>
<body>
    <div id="paypal-button-container">
        <script>
            paypal.Buttons({
            createOrder:function(data,actions) {
                return action.createOrder.create(
                    {
                        purchase_units: [{
                            amout :{
                                value '1';
                            }
                        }]
                    });
            },
            onAprove: function(data, actions){

                return actions.order.capture().then(function(details){
                    alert('Transaction completed by ' + details.payer.name.given_name);
                    window.location = ".db/conexio.php"
                });
            }
            }).render("#paypal-button-container");
        </script>
    </div>
</body>
</html>
