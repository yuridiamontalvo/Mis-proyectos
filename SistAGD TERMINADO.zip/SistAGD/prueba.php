<?php
// Incluir el archivo de conexión
include('conexion.php');  // Asegúrate de que la ruta sea correcta

try {
    // Consultar todos los datos de la tabla dbo.admDocumentos
    $sql = "SELECT * FROM dbo.admDocumentos";
    $stmt = $conn->query($sql);  // Usar la conexión ya establecida en conexion.php
    
    // Mostrar los resultados en una tabla HTML
    echo "<h2>Datos de la tabla dbo.admDocumentos</h2>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr>";
    
    // Obtener los nombres de las columnas y mostrarlas como encabezados de tabla
    $columns = $stmt->fetch(PDO::FETCH_ASSOC);
    foreach ($columns as $columnName => $value) {
        echo "<th>$columnName</th>";
    }
    echo "</tr>";
    
    // Volver al principio del conjunto de resultados y mostrar las filas
    $stmt->execute();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        foreach ($row as $value) {
            echo "<td>$value</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    
} catch (PDOException $e) {
    // Si hay un error, lo mostramos
    echo "Error de consulta: " . $e->getMessage();
}

// No es necesario cerrar la conexión, porque la gestionamos en conexion.php
?>
