<?php
$conn = new mysqli("localhost","root","","loginvaii");
	
	if($conn->connect_errno)
	{
		echo "No hay conexión: (" . $conn->connect_errno . ") " . $conn->connect_error;
	}